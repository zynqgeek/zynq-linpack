zynq-linpack
============

Linpack source by Bonnie Toy.  Very slightly modified to compile for ARM processor within Xilinx Zynq-7000 EPP